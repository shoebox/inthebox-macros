inthebox-macros
========
A set of macros for your native extensions
---------------------------------------------------------------
